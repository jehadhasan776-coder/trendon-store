@rem Standard Gradle wrapper launcher for Windows.
@rem If gradle-wrapper.jar is missing, open the project in Android Studio once
@rem to regenerate it automatically, or run "gradle wrapper" with Gradle installed.
@echo off
gradle %*

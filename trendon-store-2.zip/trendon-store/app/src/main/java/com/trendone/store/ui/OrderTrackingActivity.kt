package com.trendone.store.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.trendone.store.R
import com.trendone.store.aws.AwsClientProvider
import com.trendone.store.aws.DynamoDBManager
import com.trendone.store.databinding.ActivityOrderTrackingBinding
import com.trendone.store.models.Order
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

/**
 * تتيح تتبع الطلبات لمستخدم مسجل (تلقائياً برقم هاتفه) أو كضيف (بإدخال رقم الهاتف يدوياً).
 */
class OrderTrackingActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ORDER_ID = "extra_order_id"
    }

    private lateinit var binding: ActivityOrderTrackingBinding
    private val dbManager by lazy { DynamoDBManager(AwsClientProvider.credentialsProvider) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderTrackingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonSearchOrders.setOnClickListener { searchByPhone() }

        val orderId = intent.getStringExtra(EXTRA_ORDER_ID)
        if (!orderId.isNullOrBlank()) {
            loadSingleOrder(orderId)
        }
    }

    private fun searchByPhone() {
        val phone = binding.editPhoneNumber.text.toString().trim()
        if (phone.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_enter_phone), Toast.LENGTH_SHORT).show()
            return
        }
        binding.progressBar.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            val result = dbManager.getOrdersByPhoneNumber(phone)
            binding.progressBar.visibility = android.view.View.GONE
            result.onSuccess { orders -> renderOrders(orders) }
                .onFailure { Toast.makeText(this@OrderTrackingActivity, getString(R.string.error_generic), Toast.LENGTH_SHORT).show() }
        }
    }

    private fun loadSingleOrder(orderId: String) {
        binding.progressBar.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            dbManager.getOrderById(orderId).onSuccess { order ->
                binding.progressBar.visibility = android.view.View.GONE
                renderOrders(listOfNotNull(order))
            }
        }
    }

    private fun renderOrders(orders: List<Order>) {
        if (orders.isEmpty()) {
            binding.textOrdersList.text = getString(R.string.no_orders_found)
            return
        }
        val format = NumberFormat.getCurrencyInstance(Locale("ar", "JO"))
        binding.textOrdersList.text = orders.joinToString("\n\n") { order ->
            getString(
                R.string.order_summary_line,
                order.orderId.take(8), order.status, format.format(order.total), order.governorate
            )
        }
    }
}

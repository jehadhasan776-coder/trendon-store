package com.trendone.store.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.trendone.store.R
import com.trendone.store.aws.AwsClientProvider
import com.trendone.store.aws.CognitoAuthManager
import com.trendone.store.aws.DynamoDBManager
import com.trendone.store.databinding.ActivityCartBinding
import com.trendone.store.models.JordanGovernorate
import com.trendone.store.models.Order
import com.trendone.store.models.OrderItem
import com.trendone.store.models.PaymentMethod
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class CartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCartBinding
    private val dbManager by lazy { DynamoDBManager(AwsClientProvider.credentialsProvider) }
    private val authManager = CognitoAuthManager()
    private var appliedDiscountPercentage = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val governorateNames = JordanGovernorate.values().map { it.displayName }
        binding.spinnerGovernorate.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, governorateNames
        )
        binding.spinnerGovernorate.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                updateTotals()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        })

        binding.recyclerCartItems.layoutManager = LinearLayoutManager(this)
        renderCartItems()
        prefillIfLoggedIn()

        binding.buttonApplyDiscount.setOnClickListener { applyDiscountCode() }
        binding.buttonPlaceOrder.setOnClickListener { showConfirmationDialog() }

        updateTotals()
    }

    private fun renderCartItems() {
        val summary = CartHolder.items.joinToString("\n") {
            "${it.product.name}  x${it.quantity}  =  ${formatPrice(it.subtotal)}"
        }
        binding.textCartItemsSummary.text =
            summary.ifEmpty { getString(R.string.cart_empty) }
        binding.buttonPlaceOrder.isEnabled = CartHolder.items.isNotEmpty()
    }

    private fun prefillIfLoggedIn() {
        val username = authManager.getCurrentUsername() ?: return
        lifecycleScope.launch {
            dbManager.getUserById(username).onSuccess { user ->
                if (user != null) {
                    binding.editRecipientName.setText(user.fullName)
                    binding.editPhoneNumber.setText(user.phoneNumber)
                    binding.editDetailedAddress.setText(user.detailedAddress)
                    val index = JordanGovernorate.values().indexOfFirst { it.displayName == user.governorate }
                    if (index >= 0) binding.spinnerGovernorate.setSelection(index)
                }
            }
        }
    }

    private fun applyDiscountCode() {
        val code = binding.editDiscountCode.text.toString().trim()
        if (code.isEmpty()) return
        lifecycleScope.launch {
            dbManager.validateDiscountCode(code).onSuccess { percentage ->
                appliedDiscountPercentage = percentage
                Toast.makeText(this@CartActivity, getString(R.string.discount_applied, percentage), Toast.LENGTH_SHORT).show()
                updateTotals()
            }.onFailure { error ->
                appliedDiscountPercentage = 0.0
                Toast.makeText(this@CartActivity, error.message, Toast.LENGTH_SHORT).show()
                updateTotals()
            }
        }
    }

    private fun selectedGovernorate(): JordanGovernorate {
        val index = binding.spinnerGovernorate.selectedItemPosition.coerceAtLeast(0)
        return JordanGovernorate.values()[index]
    }

    private fun updateTotals() {
        val subtotal = CartHolder.subtotal()
        val governorate = selectedGovernorate()
        val discountAmount = subtotal * (appliedDiscountPercentage / 100.0)
        val total = (subtotal - discountAmount + governorate.shippingCost).coerceAtLeast(0.0)

        binding.textSubtotal.text = formatPrice(subtotal)
        binding.textShippingCost.text = formatPrice(governorate.shippingCost)
        binding.textDiscountAmount.text = formatPrice(discountAmount)
        binding.textTotal.text = formatPrice(total)
    }

    private fun showConfirmationDialog() {
        val name = binding.editRecipientName.text.toString().trim()
        val phone = binding.editPhoneNumber.text.toString().trim()
        val address = binding.editDetailedAddress.text.toString().trim()

        if (name.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_fill_shipping_info), Toast.LENGTH_SHORT).show()
            return
        }

        val governorate = selectedGovernorate()
        val subtotal = CartHolder.subtotal()
        val discountAmount = subtotal * (appliedDiscountPercentage / 100.0)
        val total = (subtotal - discountAmount + governorate.shippingCost).coerceAtLeast(0.0)

        val message = getString(
            R.string.order_review_message,
            formatPrice(subtotal), formatPrice(discountAmount),
            formatPrice(governorate.shippingCost), formatPrice(total), governorate.displayName, address
        )

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_order_title))
            .setMessage(message)
            .setPositiveButton(getString(R.string.cash_on_delivery)) { _, _ ->
                placeOrder(name, phone, address, governorate, PaymentMethod.CASH_ON_DELIVERY)
            }
            .setNeutralButton(getString(R.string.order_via_whatsapp)) { _, _ ->
                placeOrder(name, phone, address, governorate, PaymentMethod.WHATSAPP_ORDER)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun placeOrder(
        name: String, phone: String, address: String,
        governorate: JordanGovernorate, paymentMethod: PaymentMethod
    ) {
        val subtotal = CartHolder.subtotal()
        val discountAmount = subtotal * (appliedDiscountPercentage / 100.0)
        val total = (subtotal - discountAmount + governorate.shippingCost).coerceAtLeast(0.0)

        val order = Order(
            userId = authManager.getCurrentUsername().orEmpty(),
            guestPhoneNumber = phone,
            items = CartHolder.items.map {
                OrderItem(it.product.productId, it.product.name, it.product.price, it.quantity)
            },
            subtotal = subtotal,
            discountAmount = discountAmount,
            shippingCost = governorate.shippingCost,
            total = total,
            governorate = governorate.displayName,
            detailedAddress = address,
            recipientName = name,
            phoneNumber = phone,
            paymentMethod = paymentMethod.name
        )

        binding.progressBar.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            val result = dbManager.createOrder(order)
            binding.progressBar.visibility = android.view.View.GONE
            result.onSuccess { savedOrder ->
                CartHolder.clear()
                if (paymentMethod == PaymentMethod.WHATSAPP_ORDER) {
                    openWhatsAppWithOrder(savedOrder)
                }
                val intent = android.content.Intent(this@CartActivity, OrderConfirmationActivity::class.java)
                intent.putExtra(OrderConfirmationActivity.EXTRA_ORDER_ID, savedOrder.orderId)
                startActivity(intent)
                finish()
            }.onFailure {
                Toast.makeText(this@CartActivity, getString(R.string.error_placing_order), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openWhatsAppWithOrder(order: Order) {
        val itemsText = order.items.joinToString("\n") { "- ${it.productName} x${it.quantity}" }
        val text = getString(R.string.whatsapp_order_template, order.orderId, itemsText, formatPrice(order.total), order.governorate, order.detailedAddress)
        val uri = android.net.Uri.parse("https://wa.me/?text=" + java.net.URLEncoder.encode(text, "UTF-8"))
        startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri))
    }

    private fun formatPrice(price: Double): String =
        NumberFormat.getCurrencyInstance(Locale("ar", "JO")).format(price)
}

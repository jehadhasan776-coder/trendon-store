package com.trendone.store.models

/** المحافظات الأردنية ورسوم التوصيل الخاصة بكل محافظة */
enum class JordanGovernorate(val displayName: String, val shippingCost: Double) {
    AMMAN("عمّان", 2.0),
    IRBID("إربد", 3.0),
    ZARQA("الزرقاء", 2.5),
    BALQA("البلقاء", 3.0),
    MADABA("مادبا", 3.0),
    KARAK("الكرك", 4.0),
    TAFILAH("الطفيلة", 4.5),
    MAAN("معان", 5.0),
    AQABA("العقبة", 5.0),
    JERASH("جرش", 3.0),
    AJLOUN("عجلون", 3.5),
    MAFRAQ("المفرق", 4.0)
}

enum class OrderStatus(val displayName: String) {
    PENDING("معلق"),
    PROCESSING("قيد التجهيز"),
    SHIPPED("تم الشحن"),
    COMPLETED("مكتمل"),
    CANCELLED("ملغي")
}

enum class PaymentMethod {
    CASH_ON_DELIVERY,
    WHATSAPP_ORDER
}

data class User(
    val userId: String = "",
    val fullName: String = "",
    val phoneNumber: String = "",
    val email: String = "",
    val governorate: String = "",
    val detailedAddress: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class Product(
    val productId: String = "",
    val name: String = "",
    val description: String = "",
    val price: Double = 0.0,
    val imageUrl: String = "",
    val category: String = "",
    val stockQuantity: Int = 0,
    val isAvailable: Boolean = true
)

data class CartItem(
    val product: Product,
    var quantity: Int = 1
) {
    val subtotal: Double get() = product.price * quantity
}

data class DiscountCode(
    val code: String = "",
    val percentage: Double = 0.0,
    val isActive: Boolean = true,
    val expiryDate: Long = 0L
)

data class OrderItem(
    val productId: String = "",
    val productName: String = "",
    val price: Double = 0.0,
    val quantity: Int = 0
)

data class Order(
    val orderId: String = "",
    val userId: String = "",
    val guestPhoneNumber: String = "",
    val items: List<OrderItem> = emptyList(),
    val subtotal: Double = 0.0,
    val discountCode: String = "",
    val discountAmount: Double = 0.0,
    val shippingCost: Double = 0.0,
    val total: Double = 0.0,
    val governorate: String = "",
    val detailedAddress: String = "",
    val recipientName: String = "",
    val phoneNumber: String = "",
    val paymentMethod: String = PaymentMethod.CASH_ON_DELIVERY.name,
    val status: String = OrderStatus.PENDING.name,
    val createdAt: Long = System.currentTimeMillis()
)

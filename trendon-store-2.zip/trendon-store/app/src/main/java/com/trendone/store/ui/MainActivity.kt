package com.trendone.store.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.trendone.store.adapters.ProductAdapter
import com.trendone.store.aws.AwsClientProvider
import com.trendone.store.aws.CognitoAuthManager
import com.trendone.store.aws.DynamoDBManager
import com.trendone.store.databinding.ActivityMainBinding
import com.trendone.store.models.Product
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val dbManager by lazy { DynamoDBManager(AwsClientProvider.credentialsProvider) }
    private val authManager = CognitoAuthManager()
    private lateinit var adapter: ProductAdapter

    private val cart = CartHolder

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ProductAdapter { product -> openProductDetail(product) }
        binding.recyclerProducts.layoutManager = GridLayoutManager(this, 2)
        binding.recyclerProducts.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadProducts() }
        binding.fabCart.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }
        binding.iconAccount.setOnClickListener { openAccountArea() }

        loadProducts()
    }

    override fun onResume() {
        super.onResume()
        updateCartBadge()
    }

    private fun loadProducts() {
        binding.swipeRefresh.isRefreshing = true
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val result = dbManager.getAllProducts()
            binding.swipeRefresh.isRefreshing = false
            binding.progressBar.visibility = View.GONE
            result.onSuccess { products ->
                adapter.submitList(products)
                binding.textEmptyState.visibility = if (products.isEmpty()) View.VISIBLE else View.GONE
            }.onFailure {
                binding.textEmptyState.visibility = View.VISIBLE
            }
        }
    }

    private fun openProductDetail(product: Product) {
        val intent = Intent(this, ProductDetailActivity::class.java)
        intent.putExtra(ProductDetailActivity.EXTRA_PRODUCT_ID, product.productId)
        startActivity(intent)
    }

    private fun openAccountArea() {
        if (authManager.isSignedIn()) {
            startActivity(Intent(this, OrderTrackingActivity::class.java))
        } else {
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }

    private fun updateCartBadge() {
        binding.textCartBadge.text = cart.items.sumOf { it.quantity }.toString()
        binding.textCartBadge.visibility = if (cart.items.isEmpty()) View.GONE else View.VISIBLE
    }
}

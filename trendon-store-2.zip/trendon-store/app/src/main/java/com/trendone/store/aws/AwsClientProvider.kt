package com.trendone.store.aws

import android.content.Context
import com.amazonaws.auth.CognitoCachingCredentialsProvider
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserPool
import com.amazonaws.regions.Regions

/**
 * نقطة تهيئة واحدة لكل عملاء AWS (Cognito Identity, Cognito User Pool, Credentials).
 * استدعِ AwsClientProvider.init(context) مرة واحدة داخل TrendOneApplication.onCreate().
 */
object AwsClientProvider {

    lateinit var userPool: CognitoUserPool
        private set

    lateinit var credentialsProvider: CognitoCachingCredentialsProvider
        private set

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return

        userPool = CognitoUserPool(
            context,
            AwsConfig.USER_POOL_ID,
            AwsConfig.USER_POOL_CLIENT_ID,
            null,
            Regions.fromName(AwsConfig.REGION)
        )

        credentialsProvider = CognitoCachingCredentialsProvider(
            context,
            AwsConfig.IDENTITY_POOL_ID,
            Regions.fromName(AwsConfig.REGION)
        )

        initialized = true
    }
}

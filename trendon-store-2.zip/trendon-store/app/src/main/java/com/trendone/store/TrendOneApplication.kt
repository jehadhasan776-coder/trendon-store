package com.trendone.store

import android.app.Application
import com.trendone.store.aws.AwsClientProvider

class TrendOneApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AwsClientProvider.init(applicationContext)
    }
}

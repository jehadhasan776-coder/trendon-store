package com.trendone.store.aws

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient
import com.amazonaws.services.dynamodbv2.model.AttributeValue
import com.amazonaws.services.dynamodbv2.model.DeleteItemRequest
import com.amazonaws.auth.CognitoCachingCredentialsProvider
import com.trendone.store.models.Order
import com.trendone.store.models.OrderItem
import com.trendone.store.models.Product
import com.trendone.store.models.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * مسؤول عن عمليات CRUD الخاصة بـ DynamoDB باستخدام AWS Mobile SDK مباشرة
 * (بدون الحاجة لتوليد نماذج GraphQL). يعتمد على CognitoCachingCredentialsProvider
 * المهيأ في AwsClientProvider للحصول على صلاحيات مؤقتة عبر Identity Pool.
 *
 * جميع العمليات تعمل على thread خلفي (Dispatchers.IO) وتُعيد Result<T>
 * بدل رمي الاستثناءات مباشرة، لتسهيل معالجة الأخطاء في الواجهة.
 */
class DynamoDBManager(credentialsProvider: CognitoCachingCredentialsProvider) {

    private val client = AmazonDynamoDBClient(credentialsProvider).apply {
        setRegion(com.amazonaws.regions.Region.getRegion(AwsConfig.REGION))
    }
    private val mapper = DynamoDBMapper(client)

    // ---------- المنتجات ----------

    suspend fun getAllProducts(): Result<List<Product>> = withContext(Dispatchers.IO) {
        runCatching {
            val scanResult = client.scan(
                com.amazonaws.services.dynamodbv2.model.ScanRequest()
                    .withTableName(AwsConfig.TABLE_PRODUCTS)
            )
            scanResult.items.map { it.toProduct() }
        }
    }

    suspend fun getProductById(productId: String): Result<Product?> = withContext(Dispatchers.IO) {
        runCatching {
            val key = mapOf("productId" to AttributeValue().withS(productId))
            val result = client.getItem(AwsConfig.TABLE_PRODUCTS, key)
            result.item?.toProduct()
        }
    }

    suspend fun saveProduct(product: Product): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            client.putItem(AwsConfig.TABLE_PRODUCTS, product.toAttributeMap())
        }
    }

    suspend fun deleteProduct(productId: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            client.deleteItem(
                DeleteItemRequest()
                    .withTableName(AwsConfig.TABLE_PRODUCTS)
                    .withKey(mapOf("productId" to AttributeValue().withS(productId)))
            )
        }
    }

    // ---------- الطلبات ----------

    suspend fun createOrder(order: Order): Result<Order> = withContext(Dispatchers.IO) {
        runCatching {
            val orderWithId = if (order.orderId.isBlank())
                order.copy(orderId = UUID.randomUUID().toString()) else order
            client.putItem(AwsConfig.TABLE_ORDERS, orderWithId.toAttributeMap())
            orderWithId
        }
    }

    suspend fun updateOrderStatus(orderId: String, status: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val request = com.amazonaws.services.dynamodbv2.model.UpdateItemRequest()
                    .withTableName(AwsConfig.TABLE_ORDERS)
                    .withKey(mapOf("orderId" to AttributeValue().withS(orderId)))
                    .addAttributeUpdatesEntry(
                        "status",
                        com.amazonaws.services.dynamodbv2.model.AttributeValueUpdate()
                            .withValue(AttributeValue().withS(status))
                            .withAction(com.amazonaws.services.dynamodbv2.model.AttributeAction.PUT)
                    )
                client.updateItem(request)
            }
        }

    suspend fun getOrderById(orderId: String): Result<Order?> = withContext(Dispatchers.IO) {
        runCatching {
            val key = mapOf("orderId" to AttributeValue().withS(orderId))
            client.getItem(AwsConfig.TABLE_ORDERS, key).item?.toOrder()
        }
    }

    suspend fun getOrdersByPhoneNumber(phoneNumber: String): Result<List<Order>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val scanRequest = com.amazonaws.services.dynamodbv2.model.ScanRequest()
                    .withTableName(AwsConfig.TABLE_ORDERS)
                    .withFilterExpression("phoneNumber = :p")
                    .withExpressionAttributeValues(mapOf(":p" to AttributeValue().withS(phoneNumber)))
                client.scan(scanRequest).items.map { it.toOrder() }
            }
        }

    // ---------- المستخدمون ----------

    suspend fun saveUser(user: User): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching { client.putItem(AwsConfig.TABLE_USERS, user.toAttributeMap()) }
    }

    suspend fun getUserById(userId: String): Result<User?> = withContext(Dispatchers.IO) {
        runCatching {
            val key = mapOf("userId" to AttributeValue().withS(userId))
            client.getItem(AwsConfig.TABLE_USERS, key).item?.toUser()
        }
    }

    // ---------- أكواد الخصم ----------

    suspend fun validateDiscountCode(code: String): Result<Double> = withContext(Dispatchers.IO) {
        runCatching {
            val key = mapOf("code" to AttributeValue().withS(code.uppercase()))
            val item = client.getItem(AwsConfig.TABLE_DISCOUNT_CODES, key).item
                ?: throw Exception("كود الخصم غير صالح")
            val isActive = item["isActive"]?.bool ?: false
            if (!isActive) throw Exception("كود الخصم منتهي الصلاحية")
            item["percentage"]?.n?.toDoubleOrNull() ?: 0.0
        }
    }
}

// ---------- تحويلات AttributeValue <-> نماذج البيانات ----------

private fun Product.toAttributeMap(): Map<String, AttributeValue> = mapOf(
    "productId" to AttributeValue().withS(productId.ifBlank { UUID.randomUUID().toString() }),
    "name" to AttributeValue().withS(name),
    "description" to AttributeValue().withS(description),
    "price" to AttributeValue().withN(price.toString()),
    "imageUrl" to AttributeValue().withS(imageUrl),
    "category" to AttributeValue().withS(category),
    "stockQuantity" to AttributeValue().withN(stockQuantity.toString()),
    "isAvailable" to AttributeValue().withBOOL(isAvailable)
)

private fun Map<String, AttributeValue>.toProduct(): Product = Product(
    productId = this["productId"]?.s.orEmpty(),
    name = this["name"]?.s.orEmpty(),
    description = this["description"]?.s.orEmpty(),
    price = this["price"]?.n?.toDoubleOrNull() ?: 0.0,
    imageUrl = this["imageUrl"]?.s.orEmpty(),
    category = this["category"]?.s.orEmpty(),
    stockQuantity = this["stockQuantity"]?.n?.toIntOrNull() ?: 0,
    isAvailable = this["isAvailable"]?.bool ?: true
)

private fun User.toAttributeMap(): Map<String, AttributeValue> = mapOf(
    "userId" to AttributeValue().withS(userId),
    "fullName" to AttributeValue().withS(fullName),
    "phoneNumber" to AttributeValue().withS(phoneNumber),
    "email" to AttributeValue().withS(email),
    "governorate" to AttributeValue().withS(governorate),
    "detailedAddress" to AttributeValue().withS(detailedAddress),
    "createdAt" to AttributeValue().withN(createdAt.toString())
)

private fun Map<String, AttributeValue>.toUser(): User = User(
    userId = this["userId"]?.s.orEmpty(),
    fullName = this["fullName"]?.s.orEmpty(),
    phoneNumber = this["phoneNumber"]?.s.orEmpty(),
    email = this["email"]?.s.orEmpty(),
    governorate = this["governorate"]?.s.orEmpty(),
    detailedAddress = this["detailedAddress"]?.s.orEmpty(),
    createdAt = this["createdAt"]?.n?.toLongOrNull() ?: 0L
)

private fun Order.toAttributeMap(): Map<String, AttributeValue> = mapOf(
    "orderId" to AttributeValue().withS(orderId),
    "userId" to AttributeValue().withS(userId),
    "guestPhoneNumber" to AttributeValue().withS(guestPhoneNumber),
    "itemsJson" to AttributeValue().withS(items.joinToString("|") {
        "${it.productId},${it.productName},${it.price},${it.quantity}"
    }),
    "subtotal" to AttributeValue().withN(subtotal.toString()),
    "discountCode" to AttributeValue().withS(discountCode),
    "discountAmount" to AttributeValue().withN(discountAmount.toString()),
    "shippingCost" to AttributeValue().withN(shippingCost.toString()),
    "total" to AttributeValue().withN(total.toString()),
    "governorate" to AttributeValue().withS(governorate),
    "detailedAddress" to AttributeValue().withS(detailedAddress),
    "recipientName" to AttributeValue().withS(recipientName),
    "phoneNumber" to AttributeValue().withS(phoneNumber),
    "paymentMethod" to AttributeValue().withS(paymentMethod),
    "status" to AttributeValue().withS(status),
    "createdAt" to AttributeValue().withN(createdAt.toString())
)

private fun Map<String, AttributeValue>.toOrder(): Order {
    val items = this["itemsJson"]?.s.orEmpty()
        .split("|")
        .filter { it.isNotBlank() }
        .map { entry ->
            val parts = entry.split(",")
            OrderItem(
                productId = parts.getOrElse(0) { "" },
                productName = parts.getOrElse(1) { "" },
                price = parts.getOrElse(2) { "0" }.toDoubleOrNull() ?: 0.0,
                quantity = parts.getOrElse(3) { "0" }.toIntOrNull() ?: 0
            )
        }
    return Order(
        orderId = this["orderId"]?.s.orEmpty(),
        userId = this["userId"]?.s.orEmpty(),
        guestPhoneNumber = this["guestPhoneNumber"]?.s.orEmpty(),
        items = items,
        subtotal = this["subtotal"]?.n?.toDoubleOrNull() ?: 0.0,
        discountCode = this["discountCode"]?.s.orEmpty(),
        discountAmount = this["discountAmount"]?.n?.toDoubleOrNull() ?: 0.0,
        shippingCost = this["shippingCost"]?.n?.toDoubleOrNull() ?: 0.0,
        total = this["total"]?.n?.toDoubleOrNull() ?: 0.0,
        governorate = this["governorate"]?.s.orEmpty(),
        detailedAddress = this["detailedAddress"]?.s.orEmpty(),
        recipientName = this["recipientName"]?.s.orEmpty(),
        phoneNumber = this["phoneNumber"]?.s.orEmpty(),
        paymentMethod = this["paymentMethod"]?.s.orEmpty(),
        status = this["status"]?.s.orEmpty(),
        createdAt = this["createdAt"]?.n?.toLongOrNull() ?: 0L
    )
}

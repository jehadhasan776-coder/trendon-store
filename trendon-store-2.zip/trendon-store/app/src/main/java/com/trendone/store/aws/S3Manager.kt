package com.trendone.store.aws

import android.content.Context
import android.net.Uri
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility
import com.amazonaws.services.s3.AmazonS3Client
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.UUID
import kotlin.coroutines.resume

/**
 * مسؤول عن رفع وتحميل صور المنتجات وملفات المتجر إلى حاوية S3
 * (trendonejehadstores211194 في منطقة us-east-1) باستخدام TransferUtility.
 */
class S3Manager(context: Context) {

    private val s3Client = AmazonS3Client(AwsClientProvider.credentialsProvider).apply {
        setRegion(com.amazonaws.regions.Region.getRegion(AwsConfig.REGION))
    }

    private val transferUtility = TransferUtility.builder()
        .context(context)
        .s3Client(s3Client)
        .build()

    /**
     * يرفع ملف صورة محلي إلى S3 ويعيد مفتاح الكائن (key) الذي يمكن استخدامه
     * لاحقاً لبناء رابط العرض أو استرجاع الملف.
     */
    suspend fun uploadProductImage(localFile: File): Result<String> =
        suspendCancellableCoroutine { cont ->
            val key = "${AwsConfig.S3_PRODUCTS_FOLDER}${UUID.randomUUID()}_${localFile.name}"
            val observer = transferUtility.upload(AwsConfig.S3_BUCKET_NAME, key, localFile)

            observer.setTransferListener(object : TransferListener {
                override fun onStateChanged(id: Int, state: TransferState?) {
                    if (state == TransferState.COMPLETED && cont.isActive) {
                        cont.resume(Result.success(key))
                    } else if (state == TransferState.FAILED && cont.isActive) {
                        cont.resume(Result.failure(Exception("فشل رفع الصورة")))
                    }
                }

                override fun onProgressChanged(id: Int, bytesCurrent: Long, bytesTotal: Long) {
                    // يمكن ربطها بـ ProgressBar عبر callback إضافي عند الحاجة
                }

                override fun onError(id: Int, ex: Exception?) {
                    if (cont.isActive) cont.resume(Result.failure(ex ?: Exception("خطأ غير معروف")))
                }
            })

            cont.invokeOnCancellation { transferUtility.cancel(observer.id) }
        }

    suspend fun downloadFile(key: String, destination: File): Result<Unit> =
        suspendCancellableCoroutine { cont ->
            val observer = transferUtility.download(AwsConfig.S3_BUCKET_NAME, key, destination)

            observer.setTransferListener(object : TransferListener {
                override fun onStateChanged(id: Int, state: TransferState?) {
                    if (state == TransferState.COMPLETED && cont.isActive) {
                        cont.resume(Result.success(Unit))
                    } else if (state == TransferState.FAILED && cont.isActive) {
                        cont.resume(Result.failure(Exception("فشل تحميل الملف")))
                    }
                }

                override fun onProgressChanged(id: Int, bytesCurrent: Long, bytesTotal: Long) {}

                override fun onError(id: Int, ex: Exception?) {
                    if (cont.isActive) cont.resume(Result.failure(ex ?: Exception("خطأ غير معروف")))
                }
            })
        }

    /** يبني رابط عرض مباشر لصورة عامة (Public Read) في الحاوية. */
    fun getPublicUrl(key: String): String =
        "https://${AwsConfig.S3_BUCKET_NAME}.s3.${AwsConfig.REGION}.amazonaws.com/$key"

    fun deleteFile(key: String) {
        s3Client.deleteObject(AwsConfig.S3_BUCKET_NAME, key)
    }
}

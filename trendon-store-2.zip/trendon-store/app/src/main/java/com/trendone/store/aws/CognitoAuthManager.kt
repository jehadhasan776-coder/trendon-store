package com.trendone.store.aws

import com.amazonaws.mobileconnectors.cognitoidentityprovider.*
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.AuthenticationContinuation
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.AuthenticationDetails
import com.amazonaws.mobileconnectors.cognitoidentityprovider.exceptions.CognitoParameterInvalidException
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.AuthenticationHandler
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.GenericHandler
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.SignUpHandler
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.VerificationHandler
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserAttributes
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * مسؤول عن كل عمليات المصادقة عبر AWS Cognito User Pool:
 * التسجيل، تأكيد رمز التحقق، تسجيل الدخول، تسجيل الخروج، وجلب المستخدم الحالي.
 * يعتمد على AwsClientProvider.userPool المهيأ مسبقاً في TrendOneApplication.
 */
class CognitoAuthManager {

    private val userPool get() = AwsClientProvider.userPool

    /** رقم الهاتف الأردني يُستخدم كاسم مستخدم (username) في Cognito. */
    suspend fun signUp(
        phoneNumber: String,
        password: String,
        fullName: String,
        email: String
    ): Result<Unit> = suspendCancellableCoroutine { cont ->
        val attributes = CognitoUserAttributes().apply {
            addAttribute("name", fullName)
            addAttribute("email", email)
            addAttribute("phone_number", phoneNumber)
        }

        userPool.signUpInBackground(
            phoneNumber,
            password,
            attributes,
            null,
            object : SignUpHandler {
                override fun onSuccess(
                    user: CognitoUser?,
                    signUpConfirmationState: Boolean,
                    cognitoUserCodeDeliveryDetails: com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserCodeDeliveryDetails?
                ) {
                    if (cont.isActive) cont.resume(Result.success(Unit))
                }

                override fun onFailure(exception: Exception?) {
                    if (cont.isActive) cont.resume(Result.failure(exception ?: Exception("فشل التسجيل")))
                }
            }
        )
    }

    suspend fun confirmSignUp(phoneNumber: String, confirmationCode: String): Result<Unit> =
        suspendCancellableCoroutine { cont ->
            val user = userPool.getUser(phoneNumber)
            user.confirmSignUpInBackground(confirmationCode, false, object : GenericHandler {
                override fun onSuccess() {
                    if (cont.isActive) cont.resume(Result.success(Unit))
                }

                override fun onFailure(exception: Exception?) {
                    if (cont.isActive) cont.resume(Result.failure(exception ?: Exception("فشل تأكيد الحساب")))
                }
            })
        }

    suspend fun resendConfirmationCode(phoneNumber: String): Result<Unit> =
        suspendCancellableCoroutine { cont ->
            val user = userPool.getUser(phoneNumber)
            user.resendConfirmationCodeInBackground(object : VerificationHandler {
                override fun onSuccess(codeDeliveryDetails: com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserCodeDeliveryDetails?) {
                    if (cont.isActive) cont.resume(Result.success(Unit))
                }

                override fun onFailure(exception: Exception?) {
                    if (cont.isActive) cont.resume(Result.failure(exception ?: Exception("فشل إرسال الرمز")))
                }
            })
        }

    suspend fun signIn(phoneNumber: String, password: String): Result<String> =
        suspendCancellableCoroutine { cont ->
            val user = userPool.getUser(phoneNumber)
            user.getSessionInBackground(object : AuthenticationHandler {
                override fun onSuccess(
                    userSession: com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserSession?,
                    newDevice: com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoDevice?
                ) {
                    if (cont.isActive) {
                        cont.resume(Result.success(userSession?.accessToken?.jwtToken.orEmpty()))
                    }
                }

                override fun getAuthenticationDetails(
                    authenticationContinuation: AuthenticationContinuation?,
                    userId: String?
                ) {
                    val details = AuthenticationDetails(userId, password, null)
                    authenticationContinuation?.setAuthenticationDetails(details)
                    authenticationContinuation?.continueTask()
                }

                override fun getMFACode(continuation: com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.MultiFactorAuthenticationContinuation?) {
                    // غير مفعّل حالياً في هذا التطبيق
                }

                override fun authenticationChallenge(continuation: com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.ChallengeContinuation?) {
                    // غير مستخدم حالياً
                }

                override fun onFailure(exception: Exception?) {
                    if (cont.isActive) {
                        cont.resume(Result.failure(exception ?: Exception("فشل تسجيل الدخول")))
                    }
                }
            })
        }

    fun signOut() {
        try {
            userPool.currentUser?.signOut()
        } catch (_: CognitoParameterInvalidException) {
            // لا يوجد مستخدم مسجل حالياً
        }
    }

    fun getCurrentUsername(): String? = userPool.currentUser?.userId

    fun isSignedIn(): Boolean = userPool.currentUser?.isAuthenticated ?: false
}

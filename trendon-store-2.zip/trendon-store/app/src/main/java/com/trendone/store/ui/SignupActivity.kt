package com.trendone.store.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.trendone.store.R
import com.trendone.store.aws.CognitoAuthManager
import com.trendone.store.databinding.ActivitySignupBinding
import com.trendone.store.models.JordanGovernorate
import kotlinx.coroutines.launch

class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private val authManager = CognitoAuthManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val governorates = JordanGovernorate.values().map { it.displayName }
        binding.spinnerGovernorate.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, governorates
        )

        binding.buttonSignup.setOnClickListener { attemptSignup() }
        binding.textGoToLogin.setOnClickListener { finish() }
    }

    private fun attemptSignup() {
        val fullName = binding.editFullName.text.toString().trim()
        val phone = normalizeJordanianPhone(binding.editPhoneNumber.text.toString().trim())
        val email = binding.editEmail.text.toString().trim()
        val password = binding.editPassword.text.toString()
        val address = binding.editAddress.text.toString().trim()
        val governorate = binding.spinnerGovernorate.selectedItem?.toString().orEmpty()

        if (fullName.isEmpty() || phone == null || password.length < 8 || address.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_check_fields), Toast.LENGTH_LONG).show()
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            val result = authManager.signUp(phone, password, fullName, email)
            setLoading(false)
            result.onSuccess {
                Toast.makeText(this@SignupActivity, getString(R.string.signup_success), Toast.LENGTH_SHORT).show()
                val intent = Intent(this@SignupActivity, ConfirmEmailActivity::class.java).apply {
                    putExtra(ConfirmEmailActivity.EXTRA_PHONE, phone)
                    putExtra(ConfirmEmailActivity.EXTRA_FULL_NAME, fullName)
                    putExtra(ConfirmEmailActivity.EXTRA_EMAIL, email)
                    putExtra(ConfirmEmailActivity.EXTRA_GOVERNORATE, governorate)
                    putExtra(ConfirmEmailActivity.EXTRA_ADDRESS, address)
                }
                startActivity(intent)
                finish()
            }.onFailure { error ->
                Toast.makeText(this@SignupActivity, error.message ?: getString(R.string.error_generic), Toast.LENGTH_LONG).show()
            }
        }
    }

    /** يقبل أرقام أردنية مثل 07XXXXXXXX ويحوّلها لصيغة دولية +962. */
    private fun normalizeJordanianPhone(raw: String): String? {
        val digits = raw.filter { it.isDigit() }
        return when {
            digits.startsWith("07") && digits.length == 10 -> "+962${digits.substring(1)}"
            digits.startsWith("9627") && digits.length == 12 -> "+$digits"
            digits.startsWith("+9627") -> raw
            else -> null
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.buttonSignup.isEnabled = !loading
    }
}

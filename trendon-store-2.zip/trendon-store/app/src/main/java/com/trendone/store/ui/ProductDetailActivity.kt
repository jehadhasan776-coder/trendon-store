package com.trendone.store.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.trendone.store.R
import com.trendone.store.aws.AwsClientProvider
import com.trendone.store.aws.DynamoDBManager
import com.trendone.store.databinding.ActivityProductDetailBinding
import com.trendone.store.models.Product
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class ProductDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PRODUCT_ID = "extra_product_id"
    }

    private lateinit var binding: ActivityProductDetailBinding
    private val dbManager by lazy { DynamoDBManager(AwsClientProvider.credentialsProvider) }
    private var quantity = 1
    private var currentProduct: Product? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val productId = intent.getStringExtra(EXTRA_PRODUCT_ID).orEmpty()
        loadProduct(productId)

        binding.buttonIncrease.setOnClickListener {
            quantity++
            binding.textQuantity.text = quantity.toString()
        }
        binding.buttonDecrease.setOnClickListener {
            if (quantity > 1) {
                quantity--
                binding.textQuantity.text = quantity.toString()
            }
        }
        binding.buttonAddToCart.setOnClickListener { addToCart() }
        binding.buttonBack.setOnClickListener { finish() }
    }

    private fun loadProduct(productId: String) {
        binding.progressBar.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            val result = dbManager.getProductById(productId)
            binding.progressBar.visibility = android.view.View.GONE
            result.onSuccess { product ->
                if (product == null) {
                    Toast.makeText(this@ProductDetailActivity, getString(R.string.product_not_found), Toast.LENGTH_SHORT).show()
                    finish()
                    return@onSuccess
                }
                currentProduct = product
                bindProduct(product)
            }.onFailure {
                Toast.makeText(this@ProductDetailActivity, getString(R.string.error_generic), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun bindProduct(product: Product) {
        binding.textName.text = product.name
        binding.textDescription.text = product.description
        binding.textPrice.text = NumberFormat.getCurrencyInstance(Locale("ar", "JO")).format(product.price)
        binding.buttonAddToCart.isEnabled = product.isAvailable && product.stockQuantity > 0
        Glide.with(this).load(product.imageUrl).into(binding.imageProduct)
    }

    private fun addToCart() {
        val product = currentProduct ?: return
        CartHolder.addProduct(product, quantity)
        Toast.makeText(this, getString(R.string.added_to_cart), Toast.LENGTH_SHORT).show()
        finish()
    }
}

package com.trendone.store.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.trendone.store.R
import com.trendone.store.aws.CognitoAuthManager
import com.trendone.store.aws.DynamoDBManager
import com.trendone.store.aws.AwsClientProvider
import com.trendone.store.databinding.ActivityConfirmEmailBinding
import com.trendone.store.models.User
import kotlinx.coroutines.launch

class ConfirmEmailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PHONE = "extra_phone"
        const val EXTRA_FULL_NAME = "extra_full_name"
        const val EXTRA_EMAIL = "extra_email"
        const val EXTRA_GOVERNORATE = "extra_governorate"
        const val EXTRA_ADDRESS = "extra_address"
    }

    private lateinit var binding: ActivityConfirmEmailBinding
    private val authManager = CognitoAuthManager()
    private val dbManager by lazy { DynamoDBManager(AwsClientProvider.credentialsProvider) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConfirmEmailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val phone = intent.getStringExtra(EXTRA_PHONE).orEmpty()
        binding.textInstructions.text = getString(R.string.confirm_code_sent_to, phone)

        binding.buttonConfirm.setOnClickListener { confirmCode(phone) }
        binding.textResendCode.setOnClickListener { resendCode(phone) }
    }

    private fun confirmCode(phone: String) {
        val code = binding.editConfirmationCode.text.toString().trim()
        if (code.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_enter_code), Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            val result = authManager.confirmSignUp(phone, code)
            result.onSuccess {
                saveUserProfile(phone)
            }.onFailure { error ->
                binding.progressBar.visibility = android.view.View.GONE
                Toast.makeText(this@ConfirmEmailActivity, error.message ?: getString(R.string.error_generic), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveUserProfile(phone: String) {
        val user = User(
            userId = phone,
            fullName = intent.getStringExtra(EXTRA_FULL_NAME).orEmpty(),
            phoneNumber = phone,
            email = intent.getStringExtra(EXTRA_EMAIL).orEmpty(),
            governorate = intent.getStringExtra(EXTRA_GOVERNORATE).orEmpty(),
            detailedAddress = intent.getStringExtra(EXTRA_ADDRESS).orEmpty()
        )
        lifecycleScope.launch {
            dbManager.saveUser(user)
            binding.progressBar.visibility = android.view.View.GONE
            Toast.makeText(this@ConfirmEmailActivity, getString(R.string.account_ready), Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@ConfirmEmailActivity, LoginActivity::class.java))
            finish()
        }
    }

    private fun resendCode(phone: String) {
        lifecycleScope.launch {
            authManager.resendConfirmationCode(phone)
            Toast.makeText(this@ConfirmEmailActivity, getString(R.string.code_resent), Toast.LENGTH_SHORT).show()
        }
    }
}

package com.trendone.store.ui

import com.trendone.store.models.CartItem
import com.trendone.store.models.Product

/**
 * سلة تسوق بسيطة في الذاكرة (in-memory) لمدة جلسة التطبيق.
 * يمكن استبدالها لاحقاً بتخزين محلي (Room) إذا رغبت بالاحتفاظ بالسلة بعد إغلاق التطبيق.
 */
object CartHolder {
    val items = mutableListOf<CartItem>()

    fun addProduct(product: Product, quantity: Int = 1) {
        val existing = items.find { it.product.productId == product.productId }
        if (existing != null) {
            existing.quantity += quantity
        } else {
            items.add(CartItem(product, quantity))
        }
    }

    fun updateQuantity(productId: String, quantity: Int) {
        val item = items.find { it.product.productId == productId } ?: return
        if (quantity <= 0) items.remove(item) else item.quantity = quantity
    }

    fun removeProduct(productId: String) {
        items.removeAll { it.product.productId == productId }
    }

    fun clear() = items.clear()

    fun subtotal(): Double = items.sumOf { it.subtotal }
}

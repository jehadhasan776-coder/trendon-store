package com.trendone.store.aws

/**
 * إعدادات AWS المركزية.
 * عبّئ القيم أدناه بعد إعداد Amplify (راجع SETUP.md).
 * لا تضع القيم الحقيقية هنا في مستودع عام - استخدم local.properties أو
 * ملف amplifyconfiguration.json الذي يولّده Amplify CLI بدلاً من ذلك.
 */
object AwsConfig {
    const val REGION = "us-east-1"

    // Amazon Cognito
    const val USER_POOL_ID = "REPLACE_WITH_USER_POOL_ID"
    const val USER_POOL_CLIENT_ID = "REPLACE_WITH_APP_CLIENT_ID"
    const val IDENTITY_POOL_ID = "REPLACE_WITH_IDENTITY_POOL_ID"

    // Amazon DynamoDB - أسماء الجداول
    const val TABLE_PRODUCTS = "TrendOne_Products"
    const val TABLE_ORDERS = "TrendOne_Orders"
    const val TABLE_USERS = "TrendOne_Users"
    const val TABLE_DISCOUNT_CODES = "TrendOne_DiscountCodes"

    // Amazon S3
    const val S3_BUCKET_NAME = "trendonejehadstores211194"
    const val S3_PRODUCTS_FOLDER = "products/"
}

package com.trendone.store.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.trendone.store.R
import com.trendone.store.aws.AwsClientProvider
import com.trendone.store.aws.DynamoDBManager
import com.trendone.store.databinding.ActivityOrderConfirmationBinding
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class OrderConfirmationActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ORDER_ID = "extra_order_id"
    }

    private lateinit var binding: ActivityOrderConfirmationBinding
    private val dbManager by lazy { DynamoDBManager(AwsClientProvider.credentialsProvider) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderConfirmationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val orderId = intent.getStringExtra(EXTRA_ORDER_ID).orEmpty()
        binding.textOrderId.text = getString(R.string.order_number, orderId)

        lifecycleScope.launch {
            dbManager.getOrderById(orderId).onSuccess { order ->
                if (order != null) {
                    binding.textOrderTotal.text = NumberFormat.getCurrencyInstance(Locale("ar", "JO")).format(order.total)
                    binding.textOrderAddress.text = "${order.governorate} - ${order.detailedAddress}"
                    binding.textOrderStatus.text = order.status
                }
            }
        }

        binding.buttonTrackOrder.setOnClickListener {
            val intent = Intent(this, OrderTrackingActivity::class.java)
            intent.putExtra(OrderTrackingActivity.EXTRA_ORDER_ID, orderId)
            startActivity(intent)
        }
        binding.buttonContinueShopping.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}

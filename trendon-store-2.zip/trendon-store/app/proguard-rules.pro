# قواعد ProGuard الأساسية لمكتبة AWS
-keep class com.amazonaws.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn com.amazonaws.**

# دليل إعداد AWS خطوة بخطوة

## 1) Amazon Cognito (المصادقة)

1. من AWS Console افتح **Cognito → User pools → Create user pool**.
2. اختر تسجيل الدخول باستخدام **Phone number**.
3. فعّل **Auto-verified attributes**: Phone number.
4. أنشئ **App client** بدون Secret (Public client) — تطبيقات الموبايل لا تخزن أسرار.
5. انسخ **User pool ID** و **App client ID**.
6. أنشئ **Identity pool** (Cognito Federated Identities) واربطه بالـ User Pool أعلاه، وانسخ **Identity Pool ID**.
7. ضع القيم الثلاث في `AwsConfig.kt`:
   ```kotlin
   const val USER_POOL_ID = "us-east-1_XXXXXXX"
   const val USER_POOL_CLIENT_ID = "xxxxxxxxxxxxxxxxxxxxxxxxxx"
   const val IDENTITY_POOL_ID = "us-east-1:xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
   ```

## 2) Amazon DynamoDB (قاعدة البيانات)

أنشئ 4 جداول (On-Demand capacity) بالمفاتيح التالية:

| الجدول | Partition key |
|---|---|
| `TrendOne_Products` | `productId` (String) |
| `TrendOne_Orders` | `orderId` (String) |
| `TrendOne_Users` | `userId` (String) |
| `TrendOne_DiscountCodes` | `code` (String) |

عدّل الأسماء في `AwsConfig.kt` إذا استخدمت تسمية مختلفة.

## 3) Amazon S3 (تخزين الصور)

الحاوية موجودة مسبقاً: `trendonejehadstores211194` في `us-east-1`.
لعرض الصور مباشرة من التطبيق فعّل **Block Public Access** بشكل انتقائي، وأضف
Bucket Policy تسمح بـ `s3:GetObject` للمسار `products/*` فقط.

## 4) صلاحيات IAM لـ Identity Pool

اربط دور **Authenticated role** الخاص بـ Identity Pool بصلاحيات:
- `dynamodb:GetItem`, `PutItem`, `UpdateItem`, `DeleteItem`, `Scan` على الجداول الأربعة
- `s3:PutObject`, `GetObject` على `arn:aws:s3:::trendonejehadstores211194/products/*`

## 5) البناء والتشغيل

```bash
./gradlew assembleDebug
```

أو من Android Studio مباشرة: **Run ▶**.

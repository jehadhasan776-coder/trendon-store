# ترند ون (Trend One) — تطبيق متجر إلكتروني أندرويد مرتبط بـ AWS

تطبيق أندرويد (Kotlin) لمتجر إلكتروني موجّه للسوق الأردني، مرتبط بالكامل بخدمات AWS:
**Cognito** للمصادقة، **DynamoDB** لقاعدة البيانات، و **S3** لتخزين صور المنتجات.

## ✅ الميزات المكتملة

- تسجيل حساب جديد وتأكيده برمز التحقق (AWS Cognito)
- تسجيل دخول / متابعة كضيف
- تعبئة بيانات الشحن تلقائياً للمستخدمين المسجلين
- عرض المنتجات (شبكة) من DynamoDB
- تفاصيل المنتج + إضافة للسلة بكمية قابلة للتعديل
- سلة تسوق مع حساب رسوم التوصيل حسب المحافظة الأردنية
- أكواد الخصم (نسبة مئوية) يتم التحقق منها من DynamoDB
- الدفع عند الاستلام أو إرسال الطلب عبر واتساب
- تأكيد الطلب وتتبعه (كمستخدم مسجل أو كضيف برقم الهاتف)
- CI/CD عبر GitHub Actions لبناء واختبار APK تلقائياً

## 🗂️ البنية

```
app/src/main/java/com/trendone/store/
├── aws/            # AwsConfig, AwsClientProvider, CognitoAuthManager, DynamoDBManager, S3Manager
├── models/         # Product, User, Order, CartItem, JordanGovernorate...
├── adapters/       # ProductAdapter (RecyclerView)
└── ui/             # كل الشاشات (Activities) + CartHolder
```

## 🚀 البدء السريع

راجع [SETUP.md](SETUP.md) لخطوات إعداد AWS بالتفصيل (Cognito, DynamoDB, S3, IAM).

```bash
git clone https://github.com/jehadhasan776-coder/trendon-store.git
cd trendon-store
# افتح المجلد في Android Studio (File > Open)
```

ثم عبّئ القيم الحقيقية في `app/src/main/java/com/trendone/store/aws/AwsConfig.kt`
(معرّفات Cognito وأسماء الجداول واسم حاوية S3).

## 📄 الرخصة

MIT — راجع [LICENSE.md](LICENSE.md)

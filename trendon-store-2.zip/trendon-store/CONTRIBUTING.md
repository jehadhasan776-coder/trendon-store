# المساهمة في المشروع

1. أنشئ فرعاً جديداً: `git checkout -b feature/اسم-الميزة`
2. اتبع نمط الكود الحالي (Kotlin + ViewBinding + Coroutines)
3. تأكد أن `./gradlew test` و `./gradlew assembleDebug` ينجحان محلياً
4. افتح Pull Request مع وصف واضح للتغيير
